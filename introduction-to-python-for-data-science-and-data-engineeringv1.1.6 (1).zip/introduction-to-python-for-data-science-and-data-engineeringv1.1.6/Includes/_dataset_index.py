# Databricks notebook source
remote_files = ["/avocado/", "/avocado/README.md", "/avocado/avocado.csv", "/covid/", "/covid/04-11-2020.csv", "/covid/README-1.md", "/sf-airbnb/", "/sf-airbnb/README-sf-airbnb.md", "/sf-airbnb/sf-airbnb.csv"]
