# Databricks notebook source
def greet(name):
    return f"Hello {name}, how are you?"
